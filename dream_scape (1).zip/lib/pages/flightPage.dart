import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/api_service.dart';
import '../widgets/logo.dart';
import '../providers/travelFormProvider.dart';
import '../providers/guestSelectorProvider.dart';
import '../providers/tabProvider.dart';
import '../flights.dart';

class FlightPage extends StatefulWidget {
  const FlightPage({super.key});

  @override
  State<FlightPage> createState() => _FlightPageState();
}

class _FlightPageState extends State<FlightPage> {
  List<Flight> flights = [];
  bool isLoading = false;
  String? error;
  int? selectedFlightId;
  bool hasSearched = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Провери дали има нови податоци при секоја промена
    _checkIfShouldLoad();
  }

  void _checkIfShouldLoad() {
    final provider = Provider.of<TravelFormProvider>(context, listen: false);

    if (provider.fromPlace != null &&
        provider.toPlace != null &&
        provider.startDate != null &&
        !hasSearched) {
      _loadFlights();
    }
  }

  String? _cityToIata(String? city) {
    if (city == null) return null;
    final Map<String, String> cityToIata = {
      'New York': 'JFK',
      'London': 'LHR',
      'Paris': 'CDG',
      'Tokyo': 'HND',
      'Sydney': 'SYD',
      'Skopje': 'SKP',
      'Amsterdam': 'AMS',
      'Berlin': 'BER',
      'Rome': 'FCO',
      'Madrid': 'MAD',
      'Dubai': 'DXB',
      'Singapore': 'SIN',
      'Bangkok': 'BKK',
      'Istanbul': 'IST',
      'Los Angeles': 'LAX',
      'Chicago': 'ORD',
      'Toronto': 'YYZ',
      'Vienna': 'VIE',
      'Zurich': 'ZRH',
      'Brussels': 'BRU',
    };
    return cityToIata[city];
  }

  Future<void> _loadFlights() async {
    final provider = Provider.of<TravelFormProvider>(context, listen: false);

    final fromIata = _cityToIata(provider.fromPlace);
    final toIata = _cityToIata(provider.toPlace);

    if (fromIata == null || toIata == null || provider.startDate == null) {
      setState(() {
        isLoading = false;
        hasSearched = true;
        error = 'Please complete the search form on Home page first';
        flights = [];
      });
      return;
    }

    setState(() {
      isLoading = true;
      error = null;
    });

    try {
      final fetchedFlights = await ApiService.searchFlights(
        departureIata: fromIata,
        arrivalIata: toIata,
        flightDate: provider.startDate,
        limit: 100,
      );

      setState(() {
        flights = fetchedFlights;
        isLoading = false;
        hasSearched = true;
        error = null;
      });
    } catch (apiError) {
      print('API Error: $apiError');
      // Користи демо податоци ако API не работи
      final filteredFlights = _getDemoFlights(
        provider.fromPlace!,
        provider.toPlace!,
        provider.startDate!.toIso8601String().split('T')[0],
      );

      setState(() {
        flights = filteredFlights;
        isLoading = false;
        hasSearched = true;
        error = null;
      });
    }
  }

  List<Flight> _getDemoFlights(
      String fromCity, String toCity, String departureDate) {
    // Создај демо летови базирани на барањето
    return [
      Flight(
        id: 1,
        flightNumber: 'DS101',
        flightIata: 'DS101',
        flightDate: departureDate,
        flightStatus: 'SCHEDULED',
        airlineName: 'DreamScape Airlines',
        airlineIata: 'DS',
        departureAirportName: '$fromCity Airport',
        departureAirportIata: _cityToIata(fromCity) ?? 'XXX',
        departureCity: fromCity,
        departureCountry: 'Country',
        arrivalAirportName: '$toCity Airport',
        arrivalAirportIata: _cityToIata(toCity) ?? 'YYY',
        arrivalCity: toCity,
        arrivalCountry: 'Country',
        basePrice: 299.99,
        availableSeats: 45,
        imageUrl: 'assets/images/flight1.jpg',
        durationMinutes: 180,
      ),
      Flight(
        id: 2,
        flightNumber: 'DS202',
        flightIata: 'DS202',
        flightDate: departureDate,
        flightStatus: 'SCHEDULED',
        airlineName: 'SkyJet Airways',
        airlineIata: 'SJ',
        departureAirportName: '$fromCity Airport',
        departureAirportIata: _cityToIata(fromCity) ?? 'XXX',
        departureCity: fromCity,
        departureCountry: 'Country',
        arrivalAirportName: '$toCity Airport',
        arrivalAirportIata: _cityToIata(toCity) ?? 'YYY',
        arrivalCity: toCity,
        arrivalCountry: 'Country',
        basePrice: 349.99,
        availableSeats: 32,
        imageUrl: 'assets/images/flight2.jpg',
        durationMinutes: 165,
      ),
      Flight(
        id: 3,
        flightNumber: 'DS303',
        flightIata: 'DS303',
        flightDate: departureDate,
        flightStatus: 'SCHEDULED',
        airlineName: 'Global Airlines',
        airlineIata: 'GA',
        departureAirportName: '$fromCity Airport',
        departureAirportIata: _cityToIata(fromCity) ?? 'XXX',
        departureCity: fromCity,
        departureCountry: 'Country',
        arrivalAirportName: '$toCity Airport',
        arrivalAirportIata: _cityToIata(toCity) ?? 'YYY',
        arrivalCity: toCity,
        arrivalCountry: 'Country',
        basePrice: 249.99,
        availableSeats: 58,
        imageUrl: 'assets/images/flight3.jpg',
        durationMinutes: 210,
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final guestSel = Provider.of<GuestSelectorProvider>(context);
    return Consumer<TravelFormProvider>(
      builder: (context, provider, _) {
        return Scaffold(
          backgroundColor: Colors.blue[200],
          appBar: AppBar(
            backgroundColor: Colors.blue[200],
            elevation: 0,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.white, size: 28),
              onPressed: () {
                Provider.of<TabProvider>(context, listen: false).setIndex(0);
              },
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.refresh, color: Colors.white),
                onPressed: _loadFlights,
                tooltip: 'Refresh flights',
              ),
            ],
            title: null,
          ),
          body: SafeArea(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 32),
                  const LogoWidget(),
                  const SizedBox(height: 20),

                  // Прикажи ги деталите за пребарувањето
                  if (provider.fromPlace != null || provider.toPlace != null)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Card(
                        color: Colors.white.withOpacity(0.9),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            children: [
                              Text(
                                'Your Search',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue[800],
                                ),
                              ),
                              const SizedBox(height: 12),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text('From:',
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold)),
                                  Text(
                                    provider.fromPlace ?? 'Not selected',
                                    style: TextStyle(
                                      color: provider.fromPlace != null
                                          ? Colors.green[700]
                                          : Colors.red,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text('To:',
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold)),
                                  Text(
                                    provider.toPlace ?? 'Not selected',
                                    style: TextStyle(
                                      color: provider.toPlace != null
                                          ? Colors.green[700]
                                          : Colors.red,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text('Date:',
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold)),
                                  Text(
                                    provider.startDate
                                            ?.toString()
                                            .split(' ')[0] ??
                                        'Not selected',
                                    style: TextStyle(
                                      color: provider.startDate != null
                                          ? Colors.green[700]
                                          : Colors.red,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 16),
                              if (!provider.isSearchComplete)
                                ElevatedButton(
                                  onPressed: () {
                                    Provider.of<TabProvider>(context,
                                            listen: false)
                                        .setIndex(0);
                                  },
                                  child: const Text('Go to Home to Search'),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.pinkAccent,
                                    foregroundColor: Colors.white,
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),

                  const SizedBox(height: 20),
                  Text(
                    'Available Flights',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),

                  // Информација ако нема пребарување
                  if (!hasSearched && !isLoading && provider.isSearchComplete)
                    Padding(
                      padding: const EdgeInsets.only(top: 40),
                      child: Column(
                        children: [
                          Icon(
                            Icons.search,
                            color: Colors.white,
                            size: 48,
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'Ready to search flights?',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                            ),
                          ),
                          const SizedBox(height: 12),
                          ElevatedButton(
                            onPressed: _loadFlights,
                            child: const Text('Search Flights'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.pinkAccent,
                              foregroundColor: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),

                  // Прикажи грешка ако нема комплетирано пребарување
                  if (!provider.isSearchComplete && !isLoading)
                    Padding(
                      padding: const EdgeInsets.only(top: 40),
                      child: Column(
                        children: [
                          Icon(
                            Icons.info_outline,
                            color: Colors.amber,
                            size: 48,
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'Search Form Required',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 40),
                            child: Text(
                              'Please go to Home page and complete the travel form first.',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 14,
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          ElevatedButton(
                            onPressed: () {
                              Provider.of<TabProvider>(context, listen: false)
                                  .setIndex(0);
                            },
                            child: const Text('Go to Home Page'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.pinkAccent,
                              foregroundColor: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),

                  // Прикажи loading
                  if (isLoading)
                    const Padding(
                      padding: EdgeInsets.only(top: 70),
                      child: CircularProgressIndicator(color: Colors.white),
                    ),

                  // Прикажи грешка
                  if (error != null && hasSearched)
                    Padding(
                      padding:
                          const EdgeInsets.only(top: 70, left: 20, right: 20),
                      child: Column(
                        children: [
                          Icon(
                            Icons.error_outline,
                            color: Colors.white,
                            size: 48,
                          ),
                          const SizedBox(height: 16),
                          Text(
                            error!,
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 14,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 20),
                          ElevatedButton.icon(
                            onPressed: _loadFlights,
                            icon: const Icon(Icons.refresh),
                            label: const Text('Retry'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.pinkAccent,
                              foregroundColor: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),

                  // Прикажи летови
                  if (!isLoading && hasSearched && flights.isNotEmpty)
                    Column(
                      children: [
                        const SizedBox(height: 20),
                        Text(
                          'Found ${flights.length} flight(s)',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 10),
                        SizedBox(
                          height: 310,
                          child: Stack(
                            children: [
                              ListView.builder(
                                scrollDirection: Axis.horizontal,
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 32, vertical: 3),
                                itemCount: flights.length,
                                itemBuilder: (context, index) {
                                  final flight = flights[index];
                                  final totalTickets = provider.seniorCount +
                                      provider.adultCount +
                                      provider.childCount;
                                  return Container(
                                    width: 228,
                                    margin: const EdgeInsets.only(right: 24),
                                    child: Card(
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(12),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(15),
                                              child: Image.asset(
                                                flight.imageUrl,
                                                height: 100,
                                                width: double.infinity,
                                                fit: BoxFit.cover,
                                                errorBuilder: (context, error,
                                                    stackTrace) {
                                                  return Container(
                                                    height: 100,
                                                    width: double.infinity,
                                                    color: Colors.blue[100],
                                                    child: Icon(
                                                      Icons.flight,
                                                      color: Colors.blue[300],
                                                      size: 50,
                                                    ),
                                                  );
                                                },
                                              ),
                                            ),
                                            const SizedBox(height: 10),
                                            Text(
                                              '\$${flight.basePrice.toStringAsFixed(2)}',
                                              style: const TextStyle(
                                                fontSize: 22,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            Text(
                                                'From: ${flight.departureCity}'),
                                            Text('To: ${flight.arrivalCity}'),
                                            Text('Date: ${flight.flightDate}'),
                                            const SizedBox(height: 10),
                                            SizedBox(
                                              width: double.infinity,
                                              child: ElevatedButton(
                                                onPressed: totalTickets > 0
                                                    ? () {
                                                        selectedFlightId =
                                                            flight.id;
                                                        final totalPrice =
                                                            flight.basePrice *
                                                                totalTickets;
                                                        provider.setFlightPrice(
                                                            totalPrice);
                                                        Provider.of<TabProvider>(
                                                                context,
                                                                listen: false)
                                                            .setIndex(2);
                                                      }
                                                    : null,
                                                style: ElevatedButton.styleFrom(
                                                  backgroundColor:
                                                      Colors.pinkAccent,
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            15),
                                                  ),
                                                ),
                                                child: const Text('Book Now'),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),

                  // Прикажи ако нема летови
                  if (!isLoading && hasSearched && flights.isEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 70),
                      child: Column(
                        children: [
                          Icon(
                            Icons.flight_takeoff,
                            color: Colors.white,
                            size: 48,
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'No flights found',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            'Try different dates or destinations',
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 14,
                            ),
                          ),
                          const SizedBox(height: 20),
                          ElevatedButton(
                            onPressed: () {
                              Provider.of<TabProvider>(context, listen: false)
                                  .setIndex(0);
                            },
                            child: const Text('Modify Search'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.pinkAccent,
                              foregroundColor: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),

                  // Додај ги passenger pills само ако има летови
                  if (flights.isNotEmpty)
                    Column(
                      children: [
                        const SizedBox(height: 38),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          child: SizedBox(
                            height: 50,
                            child: Row(
                              children: [
                                const Icon(Icons.arrow_back_ios,
                                    color: Colors.white54, size: 20),
                                Expanded(
                                  child: SingleChildScrollView(
                                    scrollDirection: Axis.horizontal,
                                    child: Row(
                                      children: [
                                        _pill(
                                          context,
                                          guestSel,
                                          0,
                                          "Senior",
                                          provider.seniorCount,
                                          () => provider.setSeniorCount(
                                              provider.seniorCount + 1),
                                          () => provider.setSeniorCount(
                                              provider.seniorCount - 1),
                                          Colors.deepPurple,
                                          Icons.elderly,
                                        ),
                                        _pill(
                                          context,
                                          guestSel,
                                          1,
                                          "Adult",
                                          provider.adultCount,
                                          () => provider.setAdultCount(
                                              provider.adultCount + 1),
                                          () => provider.setAdultCount(
                                              provider.adultCount - 1),
                                          Colors.blue,
                                          Icons.person,
                                        ),
                                        _pill(
                                          context,
                                          guestSel,
                                          2,
                                          "Child",
                                          provider.childCount,
                                          () => provider.setChildCount(
                                              provider.childCount + 1),
                                          () => provider.setChildCount(
                                              provider.childCount - 1),
                                          Colors.orange,
                                          Icons.child_care,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                const Icon(Icons.arrow_forward_ios,
                                    color: Colors.white54, size: 20),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 38),
                      ],
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _pill(
    BuildContext context,
    GuestSelectorProvider guestSel,
    int idx,
    String label,
    int value,
    VoidCallback add,
    VoidCallback remove,
    Color color,
    IconData icon,
  ) {
    final bool selected = guestSel.selected == idx;
    return GestureDetector(
      onTap: () => guestSel.setSelected(idx),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? color.withOpacity(0.22) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? color : color.withOpacity(0.5),
            width: selected ? 2.5 : 1,
          ),
          boxShadow: selected
              ? [
                  BoxShadow(
                    color: color.withOpacity(.19),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  )
                ]
              : [],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 6),
            Text(label,
                style: TextStyle(color: color, fontWeight: FontWeight.bold)),
            IconButton(
              onPressed: value > 0 ? remove : null,
              icon: const Icon(Icons.remove_circle, color: Colors.red),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
            ),
            Text('$value'),
            IconButton(
              onPressed: add,
              icon: const Icon(Icons.add_circle, color: Colors.green),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
            ),
          ],
        ),
      ),
    );
  }
}
